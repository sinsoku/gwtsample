// Copyright 2011 Google Inc. All rights reserved.
package com.google.appengine.api.search;

/**
 * Thrown to indicate that a search service failure occurred while listing
 * indexes.
 *
 */
public class ListIndexesException extends SearchBaseException {
  private static final long serialVersionUID = 3608247775865189592L;

  /**
   * Constructs an exception when some error occurred in
   * the search service when listing indexes.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   */
  public ListIndexesException(OperationResult operationResult) {
    super(operationResult);
  }
}
