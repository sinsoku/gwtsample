

  package com.google.appengine.api.search;

import org.antlr.runtime.*;

import org.antlr.runtime.tree.*;

public class ExpressionParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "NEG", "INDEX", "FN", "LT", "LE", "GT", "GE", "EQ", "NE", "PLUS", "MINUS", "TIMES", "DIV", "LPAREN", "RPAREN", "LSQUARE", "INT", "RSQUARE", "NAME", "FLOAT", "PHRASE", "DIGIT", "QUOTE", "ESC_SEQ", "EXPONENT", "NAME_START", "WS", "ASCII_LETTER", "UNDERSCORE", "DOLLAR", "HEX_DIGIT", "UNICODE_ESC", "OCTAL_ESC", "'.'", "','", "'abs'", "'count'", "'distance'", "'geopoint'", "'if'", "'len'", "'log'", "'max'", "'min'", "'pow'", "'snippet'"
    };
    public static final int DOLLAR=33;
    public static final int LT=7;
    public static final int EXPONENT=28;
    public static final int LSQUARE=19;
    public static final int ASCII_LETTER=31;
    public static final int OCTAL_ESC=36;
    public static final int FLOAT=23;
    public static final int NAME_START=29;
    public static final int EOF=-1;
    public static final int LPAREN=17;
    public static final int INDEX=5;
    public static final int RPAREN=18;
    public static final int QUOTE=26;
    public static final int NAME=22;
    public static final int ESC_SEQ=27;
    public static final int PLUS=13;
    public static final int DIGIT=25;
    public static final int EQ=11;
    public static final int NE=12;
    public static final int T__42=42;
    public static final int T__43=43;
    public static final int T__40=40;
    public static final int GE=10;
    public static final int T__41=41;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int UNICODE_ESC=35;
    public static final int HEX_DIGIT=34;
    public static final int UNDERSCORE=32;
    public static final int INT=20;
    public static final int FN=6;
    public static final int MINUS=14;
    public static final int RSQUARE=21;
    public static final int PHRASE=24;
    public static final int WS=30;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int NEG=4;
    public static final int GT=9;
    public static final int DIV=16;
    public static final int TIMES=15;
    public static final int LE=8;

        public ExpressionParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public ExpressionParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);

        }

    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return ExpressionParser.tokenNames; }
    public String getGrammarFileName() { return "java/com/google/appengine/api/search/Expression.g"; }

      @Override
      public Object recoverFromMismatchedSet(IntStream input,
          RecognitionException e, BitSet follow) throws RecognitionException {
        throw e;
      }

      @Override
      protected Object recoverFromMismatchedToken(
          IntStream input, int ttype, BitSet follow) throws RecognitionException {
        throw new MismatchedTokenException(ttype, input);
      }

    public static class expression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.expression_return expression() throws RecognitionException {
        ExpressionParser.expression_return retval = new ExpressionParser.expression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token EOF2=null;
        ExpressionParser.cmpExpr_return cmpExpr1 = null;

        CommonTree EOF2_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_cmpExpr_in_expression87);
            cmpExpr1=cmpExpr();

            state._fsp--;

            adaptor.addChild(root_0, cmpExpr1.getTree());
            EOF2=(Token)match(input,EOF,FOLLOW_EOF_in_expression89);
            EOF2_tree = (CommonTree)adaptor.create(EOF2);
            adaptor.addChild(root_0, EOF2_tree);

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class cmpExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.cmpExpr_return cmpExpr() throws RecognitionException {
        ExpressionParser.cmpExpr_return retval = new ExpressionParser.cmpExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        ExpressionParser.addExpr_return addExpr3 = null;

        ExpressionParser.cmpOp_return cmpOp4 = null;

        ExpressionParser.addExpr_return addExpr5 = null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_addExpr_in_cmpExpr102);
            addExpr3=addExpr();

            state._fsp--;

            adaptor.addChild(root_0, addExpr3.getTree());
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( ((LA1_0>=LT && LA1_0<=NE)) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    {
                    pushFollow(FOLLOW_cmpOp_in_cmpExpr105);
                    cmpOp4=cmpOp();

                    state._fsp--;

                    root_0 = (CommonTree)adaptor.becomeRoot(cmpOp4.getTree(), root_0);
                    pushFollow(FOLLOW_addExpr_in_cmpExpr108);
                    addExpr5=addExpr();

                    state._fsp--;

                    adaptor.addChild(root_0, addExpr5.getTree());

                    }
                    break;

            }

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class cmpOp_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.cmpOp_return cmpOp() throws RecognitionException {
        ExpressionParser.cmpOp_return retval = new ExpressionParser.cmpOp_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set6=null;

        CommonTree set6_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            set6=(Token)input.LT(1);
            if ( (input.LA(1)>=LT && input.LA(1)<=NE) ) {
                input.consume();
                adaptor.addChild(root_0, (CommonTree)adaptor.create(set6));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class addExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.addExpr_return addExpr() throws RecognitionException {
        ExpressionParser.addExpr_return retval = new ExpressionParser.addExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        ExpressionParser.multExpr_return multExpr7 = null;

        ExpressionParser.addOp_return addOp8 = null;

        ExpressionParser.multExpr_return multExpr9 = null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_multExpr_in_addExpr166);
            multExpr7=multExpr();

            state._fsp--;

            adaptor.addChild(root_0, multExpr7.getTree());
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=PLUS && LA2_0<=MINUS)) ) {
                    alt2=1;
                }

                switch (alt2) {
            	case 1 :
            	    {
            	    pushFollow(FOLLOW_addOp_in_addExpr169);
            	    addOp8=addOp();

            	    state._fsp--;

            	    root_0 = (CommonTree)adaptor.becomeRoot(addOp8.getTree(), root_0);
            	    pushFollow(FOLLOW_multExpr_in_addExpr172);
            	    multExpr9=multExpr();

            	    state._fsp--;

            	    adaptor.addChild(root_0, multExpr9.getTree());

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class addOp_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.addOp_return addOp() throws RecognitionException {
        ExpressionParser.addOp_return retval = new ExpressionParser.addOp_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set10=null;

        CommonTree set10_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            set10=(Token)input.LT(1);
            if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
                input.consume();
                adaptor.addChild(root_0, (CommonTree)adaptor.create(set10));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class multExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.multExpr_return multExpr() throws RecognitionException {
        ExpressionParser.multExpr_return retval = new ExpressionParser.multExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        ExpressionParser.unary_return unary11 = null;

        ExpressionParser.multOp_return multOp12 = null;

        ExpressionParser.unary_return unary13 = null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_unary_in_multExpr206);
            unary11=unary();

            state._fsp--;

            adaptor.addChild(root_0, unary11.getTree());
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>=TIMES && LA3_0<=DIV)) ) {
                    alt3=1;
                }

                switch (alt3) {
            	case 1 :
            	    {
            	    pushFollow(FOLLOW_multOp_in_multExpr209);
            	    multOp12=multOp();

            	    state._fsp--;

            	    root_0 = (CommonTree)adaptor.becomeRoot(multOp12.getTree(), root_0);
            	    pushFollow(FOLLOW_unary_in_multExpr212);
            	    unary13=unary();

            	    state._fsp--;

            	    adaptor.addChild(root_0, unary13.getTree());

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class multOp_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.multOp_return multOp() throws RecognitionException {
        ExpressionParser.multOp_return retval = new ExpressionParser.multOp_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set14=null;

        CommonTree set14_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            set14=(Token)input.LT(1);
            if ( (input.LA(1)>=TIMES && input.LA(1)<=DIV) ) {
                input.consume();
                adaptor.addChild(root_0, (CommonTree)adaptor.create(set14));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class unary_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.unary_return unary() throws RecognitionException {
        ExpressionParser.unary_return retval = new ExpressionParser.unary_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token MINUS15=null;
        ExpressionParser.atom_return atom16 = null;

        ExpressionParser.atom_return atom17 = null;

        CommonTree MINUS15_tree=null;
        RewriteRuleTokenStream stream_MINUS=new RewriteRuleTokenStream(adaptor,"token MINUS");
        RewriteRuleSubtreeStream stream_atom=new RewriteRuleSubtreeStream(adaptor,"rule atom");
        try {
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==MINUS) ) {
                alt4=1;
            }
            else if ( (LA4_0==LPAREN||LA4_0==INT||(LA4_0>=NAME && LA4_0<=PHRASE)||(LA4_0>=39 && LA4_0<=49)) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    {
                    MINUS15=(Token)match(input,MINUS,FOLLOW_MINUS_in_unary246);
                    stream_MINUS.add(MINUS15);

                    pushFollow(FOLLOW_atom_in_unary248);
                    atom16=atom();

                    state._fsp--;

                    stream_atom.add(atom16.getTree());

                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    {
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(NEG, "-"), root_1);

                        adaptor.addChild(root_1, stream_atom.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_atom_in_unary263);
                    atom17=atom();

                    state._fsp--;

                    adaptor.addChild(root_0, atom17.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class atom_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.atom_return atom() throws RecognitionException {
        ExpressionParser.atom_return retval = new ExpressionParser.atom_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token LPAREN22=null;
        Token RPAREN24=null;
        ExpressionParser.var_return var18 = null;

        ExpressionParser.num_return num19 = null;

        ExpressionParser.str_return str20 = null;

        ExpressionParser.fn_return fn21 = null;

        ExpressionParser.addExpr_return addExpr23 = null;

        CommonTree LPAREN22_tree=null;
        CommonTree RPAREN24_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_addExpr=new RewriteRuleSubtreeStream(adaptor,"rule addExpr");
        try {
            int alt5=5;
            switch ( input.LA(1) ) {
            case NAME:
                {
                alt5=1;
                }
                break;
            case INT:
            case FLOAT:
                {
                alt5=2;
                }
                break;
            case PHRASE:
                {
                alt5=3;
                }
                break;
            case 39:
            case 40:
            case 41:
            case 42:
            case 43:
            case 44:
            case 45:
            case 46:
            case 47:
            case 48:
            case 49:
                {
                alt5=4;
                }
                break;
            case LPAREN:
                {
                alt5=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_var_in_atom276);
                    var18=var();

                    state._fsp--;

                    adaptor.addChild(root_0, var18.getTree());

                    }
                    break;
                case 2 :
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_num_in_atom282);
                    num19=num();

                    state._fsp--;

                    adaptor.addChild(root_0, num19.getTree());

                    }
                    break;
                case 3 :
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_str_in_atom288);
                    str20=str();

                    state._fsp--;

                    adaptor.addChild(root_0, str20.getTree());

                    }
                    break;
                case 4 :
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_fn_in_atom294);
                    fn21=fn();

                    state._fsp--;

                    adaptor.addChild(root_0, fn21.getTree());

                    }
                    break;
                case 5 :
                    {
                    LPAREN22=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_atom300);
                    stream_LPAREN.add(LPAREN22);

                    pushFollow(FOLLOW_addExpr_in_atom302);
                    addExpr23=addExpr();

                    state._fsp--;

                    stream_addExpr.add(addExpr23.getTree());
                    RPAREN24=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_atom304);
                    stream_RPAREN.add(RPAREN24);

                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    {
                        adaptor.addChild(root_0, stream_addExpr.nextTree());

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class var_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.var_return var() throws RecognitionException {
        ExpressionParser.var_return retval = new ExpressionParser.var_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        ExpressionParser.name_return name25 = null;

        ExpressionParser.name_return name26 = null;

        ExpressionParser.index_return index27 = null;

        RewriteRuleSubtreeStream stream_index=new RewriteRuleSubtreeStream(adaptor,"rule index");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        try {
            int alt6=2;
            alt6 = dfa6.predict(input);
            switch (alt6) {
                case 1 :
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_name_in_var321);
                    name25=name();

                    state._fsp--;

                    adaptor.addChild(root_0, name25.getTree());

                    }
                    break;
                case 2 :
                    {
                    pushFollow(FOLLOW_name_in_var327);
                    name26=name();

                    state._fsp--;

                    stream_name.add(name26.getTree());
                    pushFollow(FOLLOW_index_in_var329);
                    index27=index();

                    state._fsp--;

                    stream_index.add(index27.getTree());

                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    {
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(INDEX, (index27!=null?input.toString(index27.start,index27.stop):null)), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class index_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.index_return index() throws RecognitionException {
        ExpressionParser.index_return retval = new ExpressionParser.index_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token x=null;
        Token LSQUARE28=null;
        Token RSQUARE29=null;

        CommonTree x_tree=null;
        CommonTree LSQUARE28_tree=null;
        CommonTree RSQUARE29_tree=null;
        RewriteRuleTokenStream stream_INT=new RewriteRuleTokenStream(adaptor,"token INT");
        RewriteRuleTokenStream stream_LSQUARE=new RewriteRuleTokenStream(adaptor,"token LSQUARE");
        RewriteRuleTokenStream stream_RSQUARE=new RewriteRuleTokenStream(adaptor,"token RSQUARE");

        try {
            {
            LSQUARE28=(Token)match(input,LSQUARE,FOLLOW_LSQUARE_in_index351);
            stream_LSQUARE.add(LSQUARE28);

            x=(Token)match(input,INT,FOLLOW_INT_in_index355);
            stream_INT.add(x);

            RSQUARE29=(Token)match(input,RSQUARE,FOLLOW_RSQUARE_in_index357);
            stream_RSQUARE.add(RSQUARE29);

            retval.tree = root_0;
            RewriteRuleTokenStream stream_x=new RewriteRuleTokenStream(adaptor,"token x",x);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            {
                adaptor.addChild(root_0, stream_x.nextNode());

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class name_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.name_return name() throws RecognitionException {
        ExpressionParser.name_return retval = new ExpressionParser.name_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NAME30=null;
        Token char_literal31=null;
        Token NAME32=null;

        CommonTree NAME30_tree=null;
        CommonTree char_literal31_tree=null;
        CommonTree NAME32_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            NAME30=(Token)match(input,NAME,FOLLOW_NAME_in_name375);
            NAME30_tree = (CommonTree)adaptor.create(NAME30);
            adaptor.addChild(root_0, NAME30_tree);

            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==37) ) {
                    alt7=1;
                }

                switch (alt7) {
            	case 1 :
            	    {
            	    char_literal31=(Token)match(input,37,FOLLOW_37_in_name378);
            	    char_literal31_tree = (CommonTree)adaptor.create(char_literal31);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal31_tree, root_0);

            	    NAME32=(Token)match(input,NAME,FOLLOW_NAME_in_name381);
            	    NAME32_tree = (CommonTree)adaptor.create(NAME32);
            	    adaptor.addChild(root_0, NAME32_tree);

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class num_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.num_return num() throws RecognitionException {
        ExpressionParser.num_return retval = new ExpressionParser.num_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set33=null;

        CommonTree set33_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            set33=(Token)input.LT(1);
            if ( input.LA(1)==INT||input.LA(1)==FLOAT ) {
                input.consume();
                adaptor.addChild(root_0, (CommonTree)adaptor.create(set33));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class str_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.str_return str() throws RecognitionException {
        ExpressionParser.str_return retval = new ExpressionParser.str_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token PHRASE34=null;

        CommonTree PHRASE34_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            PHRASE34=(Token)match(input,PHRASE,FOLLOW_PHRASE_in_str415);
            PHRASE34_tree = (CommonTree)adaptor.create(PHRASE34);
            adaptor.addChild(root_0, PHRASE34_tree);

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class fn_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.fn_return fn() throws RecognitionException {
        ExpressionParser.fn_return retval = new ExpressionParser.fn_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token LPAREN36=null;
        Token char_literal38=null;
        Token RPAREN40=null;
        ExpressionParser.fnName_return fnName35 = null;

        ExpressionParser.cmpExpr_return cmpExpr37 = null;

        ExpressionParser.cmpExpr_return cmpExpr39 = null;

        CommonTree LPAREN36_tree=null;
        CommonTree char_literal38_tree=null;
        CommonTree RPAREN40_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleTokenStream stream_38=new RewriteRuleTokenStream(adaptor,"token 38");
        RewriteRuleSubtreeStream stream_fnName=new RewriteRuleSubtreeStream(adaptor,"rule fnName");
        RewriteRuleSubtreeStream stream_cmpExpr=new RewriteRuleSubtreeStream(adaptor,"rule cmpExpr");
        try {
            {
            pushFollow(FOLLOW_fnName_in_fn428);
            fnName35=fnName();

            state._fsp--;

            stream_fnName.add(fnName35.getTree());
            LPAREN36=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_fn430);
            stream_LPAREN.add(LPAREN36);

            pushFollow(FOLLOW_cmpExpr_in_fn432);
            cmpExpr37=cmpExpr();

            state._fsp--;

            stream_cmpExpr.add(cmpExpr37.getTree());
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==38) ) {
                    alt8=1;
                }

                switch (alt8) {
            	case 1 :
            	    {
            	    char_literal38=(Token)match(input,38,FOLLOW_38_in_fn435);
            	    stream_38.add(char_literal38);

            	    pushFollow(FOLLOW_cmpExpr_in_fn437);
            	    cmpExpr39=cmpExpr();

            	    state._fsp--;

            	    stream_cmpExpr.add(cmpExpr39.getTree());

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            RPAREN40=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_fn441);
            stream_RPAREN.add(RPAREN40);

            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            {
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FN, (fnName35!=null?input.toString(fnName35.start,fnName35.stop):null)), root_1);

                if ( !(stream_cmpExpr.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_cmpExpr.hasNext() ) {
                    adaptor.addChild(root_1, stream_cmpExpr.nextTree());

                }
                stream_cmpExpr.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    public static class fnName_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    public final ExpressionParser.fnName_return fnName() throws RecognitionException {
        ExpressionParser.fnName_return retval = new ExpressionParser.fnName_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set41=null;

        CommonTree set41_tree=null;

        try {
            {
            root_0 = (CommonTree)adaptor.nil();

            set41=(Token)input.LT(1);
            if ( (input.LA(1)>=39 && input.LA(1)<=49) ) {
                input.consume();
                adaptor.addChild(root_0, (CommonTree)adaptor.create(set41));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }

          catch (RecognitionException e) {
            reportError(e);
            throw e;
          }
        finally {
        }
        return retval;
    }

    protected DFA6 dfa6 = new DFA6(this);
    static final String DFA6_eotS =
        "\6\uffff";
    static final String DFA6_eofS =
        "\1\uffff\1\3\3\uffff\1\3";
    static final String DFA6_minS =
        "\1\26\1\7\1\26\2\uffff\1\7";
    static final String DFA6_maxS =
        "\1\26\1\46\1\26\2\uffff\1\46";
    static final String DFA6_acceptS =
        "\3\uffff\1\1\1\2\1\uffff";
    static final String DFA6_specialS =
        "\6\uffff}>";
    static final String[] DFA6_transitionS = {
            "\1\1",
            "\12\3\1\uffff\1\3\1\4\21\uffff\1\2\1\3",
            "\1\5",
            "",
            "",
            "\12\3\1\uffff\1\3\1\4\21\uffff\1\2\1\3"
    };

    static final short[] DFA6_eot = DFA.unpackEncodedString(DFA6_eotS);
    static final short[] DFA6_eof = DFA.unpackEncodedString(DFA6_eofS);
    static final char[] DFA6_min = DFA.unpackEncodedStringToUnsignedChars(DFA6_minS);
    static final char[] DFA6_max = DFA.unpackEncodedStringToUnsignedChars(DFA6_maxS);
    static final short[] DFA6_accept = DFA.unpackEncodedString(DFA6_acceptS);
    static final short[] DFA6_special = DFA.unpackEncodedString(DFA6_specialS);
    static final short[][] DFA6_transition;

    static {
        int numStates = DFA6_transitionS.length;
        DFA6_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA6_transition[i] = DFA.unpackEncodedString(DFA6_transitionS[i]);
        }
    }

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = DFA6_eot;
            this.eof = DFA6_eof;
            this.min = DFA6_min;
            this.max = DFA6_max;
            this.accept = DFA6_accept;
            this.special = DFA6_special;
            this.transition = DFA6_transition;
        }
        public String getDescription() {
            return "100:1: var : ( name | name index -> ^( INDEX[$index.text] name ) );";
        }
    }

    public static final BitSet FOLLOW_cmpExpr_in_expression87 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_expression89 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_addExpr_in_cmpExpr102 = new BitSet(new long[]{0x0000000000001F82L});
    public static final BitSet FOLLOW_cmpOp_in_cmpExpr105 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_addExpr_in_cmpExpr108 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_cmpOp0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_multExpr_in_addExpr166 = new BitSet(new long[]{0x0000000000006002L});
    public static final BitSet FOLLOW_addOp_in_addExpr169 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_multExpr_in_addExpr172 = new BitSet(new long[]{0x0000000000006002L});
    public static final BitSet FOLLOW_set_in_addOp0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unary_in_multExpr206 = new BitSet(new long[]{0x0000000000018002L});
    public static final BitSet FOLLOW_multOp_in_multExpr209 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_unary_in_multExpr212 = new BitSet(new long[]{0x0000000000018002L});
    public static final BitSet FOLLOW_set_in_multOp0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_MINUS_in_unary246 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_atom_in_unary248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_in_unary263 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_var_in_atom276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_num_in_atom282 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_str_in_atom288 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fn_in_atom294 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_atom300 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_addExpr_in_atom302 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_RPAREN_in_atom304 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_var321 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_var327 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_index_in_var329 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LSQUARE_in_index351 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_INT_in_index355 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_RSQUARE_in_index357 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NAME_in_name375 = new BitSet(new long[]{0x0000002000000002L});
    public static final BitSet FOLLOW_37_in_name378 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_NAME_in_name381 = new BitSet(new long[]{0x0000002000000002L});
    public static final BitSet FOLLOW_set_in_num0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PHRASE_in_str415 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fnName_in_fn428 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_LPAREN_in_fn430 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_cmpExpr_in_fn432 = new BitSet(new long[]{0x0000004000040000L});
    public static final BitSet FOLLOW_38_in_fn435 = new BitSet(new long[]{0x0003FF8001D24000L});
    public static final BitSet FOLLOW_cmpExpr_in_fn437 = new BitSet(new long[]{0x0000004000040000L});
    public static final BitSet FOLLOW_RPAREN_in_fn441 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_fnName0 = new BitSet(new long[]{0x0000000000000002L});

}
