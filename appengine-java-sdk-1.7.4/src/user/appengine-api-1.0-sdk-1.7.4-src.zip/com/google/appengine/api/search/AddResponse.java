// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.search;

import com.google.appengine.api.search.checkers.Preconditions;

import java.io.Serializable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a result of adding a list of objects (documents or queries)
 * to an index. The response contains a list of {@link OperationResult}
 * indicating success or not of adding each of the objects, and a list
 * of Id of the objects which are those given in the request or allocated
 * by the search service to those objects which do not have an Id supplied.
 *
 * @deprecated as of 1.7.3. Use {@link PutResponse} instead.
 */
@Deprecated
public class AddResponse implements Iterable<OperationResult>, Serializable {
  private static final long serialVersionUID = 1189234703739911898L;

  private final List<OperationResult> results;
  private final List<String> ids;

  /**
   * Creates a {@link AddResponse} by specifying a list of
   * {@link OperationResult} and a list of document or query ids.
   *
   * @param results a list of {@link OperationResult} that indicate the
   * success or not adding each object
   * @param ids a list of Id of objects that were requested to be
   * added. The search service may supply Ids for those objects where
   * none was supplied
   */
  protected AddResponse(List<OperationResult> results, List<String> ids) {
    this.results = Collections.unmodifiableList(
        Preconditions.checkNotNull(results, "results cannot be null"));
    this.ids = Collections.unmodifiableList(
        Preconditions.checkNotNull(ids, "ids cannot be null"));
  }

  @Override
  public Iterator<OperationResult> iterator() {
    return results.iterator();
  }

  /**
   * @return an unmodifiable list of {@link OperationResult} indicating
   * whether each {@link Document} was added or not
   */
  public List<OperationResult> getResults() {
    return results;
  }

  /**
   * @return an unmodifiable list of Ids
   */
  public List<String> getIds() {
    return ids;
  }

  @Override
  public String toString() {
    return String.format("AddResponse(results=%s, ids=%s)",
        Util.iterableToString(getResults(), 0), Util.iterableToString(getIds(), 0));
  }
}
