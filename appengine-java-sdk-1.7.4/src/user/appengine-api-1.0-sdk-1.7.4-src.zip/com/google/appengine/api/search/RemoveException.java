// Copyright 2011 Google Inc. All rights reserved.
package com.google.appengine.api.search;

import java.util.ArrayList;
import java.util.List;

/**
 * Thrown to indicate that a search service failure occurred while removing
 * objects.
 *
 */
public class RemoveException extends SearchBaseException {
  private static final long serialVersionUID = 1877363623092870992L;

  private final List<OperationResult> results;

  /**
   * Constructs an exception when some error occurred in
   * the search service whilst processing a remove operation.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   */
  public RemoveException(OperationResult operationResult) {
    this(operationResult, new ArrayList<OperationResult>());
  }

  /**
   * Constructs an exception when some error occurred in
   * the search service whilst processing a remove operation.
   *
   * @param operationResult the error code and message detail associated with
   * the failure
   * @param results the list of {@link OperationResult} where each result is
   * associated with the id of the object that was requested to be removed
   */
  public RemoveException(OperationResult operationResult,
      List<OperationResult> results) {
    super(operationResult);
    this.results = results;
  }

  /**
   * @return the list of {@link OperationResult} where each result is
   * associated with the id of the object that was requested to be removed
   */
  public List<OperationResult> getResults() {
    return results;
  }
}
